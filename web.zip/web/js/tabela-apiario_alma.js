$(document).ready(function () {
	$('#tabelaapiario').DataTable({
		language: {
			url: 'js/dataTables.pt_br.json'
		}
	});
});
