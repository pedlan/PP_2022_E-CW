$(document).ready(function () {
	$('#tabelacolmeia').DataTable({
		language: {
			url: 'js/dataTables.pt_br.json'
		}
	});
});
