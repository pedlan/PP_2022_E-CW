package br.com.pedro.ECW;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECwApplicationTests {

	@Test
	void contextLoads() {
	}

}
